import asyncio
import yaml
import os
import pandas as pd
from rich.console import Console
from rich.progress import track
from colorama import init, Fore
from transformers import BertTokenizer, BertModel
import torch
import sqlite3
import numpy as np
import re
from typing import List, Dict, Set
import time
from rich.live import Live
from rich.table import Table
from rich.layout import Layout
from rich.panel import Panel
from rich import box
from datetime import datetime
import threading
import psutil
import GPUtil

# Inicialização
init()  # Colorama
console = Console()  # Rich

# Configuração do banco de dados
def setup_database():
    conn = sqlite3.connect('vector-blob-database.db')
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS word_vectors (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            word TEXT NOT NULL UNIQUE,
            vector_blob BLOB NOT NULL
        )
    ''')
    conn.commit()
    return conn

# Função para limpar o conteúdo do YAML
def clean_yaml_content(content: str) -> str:
    # Remove caracteres especiais no início do arquivo
    content = re.sub(r'^[`\'"]', '', content, flags=re.MULTILINE)
    # Remove blocos de código markdown
    content = re.sub(r'```.*?```', '', content, flags=re.DOTALL)
    # Remove caracteres especiais restantes
    content = re.sub(r'[^\w\s\-:{}[\],.]', ' ', content)
    return content.strip()

# Função para processar YAML
async def process_yaml_file(file_path: str) -> Set[str]:
    console.print(f"🔍 [cyan]Processando arquivo:[/cyan] {file_path}")
    
    try:
        with open(file_path, 'r', encoding='utf-8') as file:
            # Lê e limpa o conteúdo antes do parsing
            raw_content = file.read()
            cleaned_content = clean_yaml_content(raw_content)
            
            # Tenta fazer o parsing do YAML
            try:
                yaml_content = yaml.safe_load(cleaned_content)
            except yaml.YAMLError as e:
                console.print(f"⚠️ [yellow]Erro de parsing YAML:[/yellow] {e}, tentando como texto puro...")
                yaml_content = {'text': cleaned_content}
            
            words = set()
            
            def extract_words(content):
                if isinstance(content, dict):
                    for value in content.values():
                        extract_words(value)
                elif isinstance(content, list):
                    for item in content:
                        extract_words(item)
                elif isinstance(content, str):
                    # Ignora URLs
                    if not re.match(r'http[s]?://', content):
                        # Divide e limpa as palavras
                        clean_words = re.findall(r'\w+', content.lower())
                        words.update(clean_words)
            
            extract_words(yaml_content)
            console.print(f"✨ [green]Encontradas {len(words)} palavras únicas[/green]")
            return words
            
    except FileNotFoundError:
        console.print(f"⚠️ [yellow]Arquivo não encontrado:[/yellow] {file_path}")
        return set()
    except Exception as e:
        console.print(f"❌ [red]Erro fatal ao processar arquivo:[/red] {e}")
        return set()

# Função para criar embedding
def create_embedding(word: str) -> np.ndarray:
    try:
        inputs = tokenizer(word, return_tensors="pt", padding=True, truncation=True)
        with torch.no_grad():
            outputs = model(**inputs)
        return outputs.last_hidden_state.mean(dim=1).numpy()[0]
    except Exception as e:
        console.print(f"[red]Erro ao criar embedding para '{word}': {e}[/red]")
        return np.zeros(768) # Retorna um vetor zero em caso de erro

# Função para processar palavras sequencialmente
async def process_words(words: Set[str]) -> pd.DataFrame:
    console.print("🔄 [yellow]Processando embeddings...[/yellow]")
    
    df = pd.DataFrame(columns=['word', 'embedding'])
    
    embeddings = [create_embedding(word) for word in words]
    
    df['word'] = list(words)
    df['embedding'] = embeddings
    
    return df

# Função para salvar no banco
async def save_to_database(df: pd.DataFrame, conn: sqlite3.Connection, progress_callback=None):
    console.print("💾 [blue]Salvando no banco de dados...[/blue]")
    
    cursor = conn.cursor()
    batch_size = 1000
    
    async def empty_callback():
        await asyncio.sleep(0)

    if progress_callback is None:
        progress_callback = empty_callback

    try:
        for i in track(range(0, len(df), batch_size)):
            batch = df.iloc[i:i + batch_size]
            
            # Usa executemany para inserção em lote
            data = [(row['word'], row['embedding'].tobytes()) 
                   for _, row in batch.iterrows()]
            
            cursor.executemany(
                'INSERT OR IGNORE INTO word_vectors (word, vector_blob) VALUES (?, ?)',
                data
            )
            
            await progress_callback()
            
            conn.commit()
            
        console.print("✅ [green]Dados salvos com sucesso![/green]")
    except sqlite3.Error as e:
        console.print(f"❌ [red]Erro ao salvar no banco de dados:[/red] {e}")
    finally:
        conn.close()

# Contadores globais com thread safety
class EnhancedCounters:
    def __init__(self):
        self.lock = threading.Lock()
        self.processed_files = 0
        self.total_words = 0
        self.processed_embeddings = 0
        self.saved_to_db = 0
        self.errors = 0
        self.start_time = time.time()
        self.batch_times = []
        self.memory_usage = []
        self.gpu_usage = []
        self.cpu_usage = []
        self.processed_files_list = []
        self.tokens_count = 0
        self.bert_metrics = {'tokens': 0, 'inference_time': 0.0} # Adiciona métricas do BERT

    def update_system_metrics(self):
        self.memory_usage.append(psutil.Process().memory_percent())
        self.cpu_usage.append(psutil.cpu_percent())
        try:
            gpus = GPUtil.getGPUs()
            if gpus:
                self.gpu_usage.append(gpus[0].load * 100)
        except:
            self.gpu_usage.append(0)

counters = EnhancedCounters()

def create_layout() -> Layout:
    layout = Layout()
    layout.split_column(
        Layout(name="header", size=3),
        Layout(name="main"),
        Layout(name="footer", size=3)
    )
    layout["main"].split_row(
        Layout(name="stats"),
        Layout(name="progress"),
        Layout(name="details")
    )
    return layout

def generate_stats_table() -> Table:
    table = Table(title="📊 Estatísticas", box=box.ROUNDED)
    table.add_column("Métrica", style="cyan")
    table.add_column("Valor", justify="right", style="green")
    
    elapsed = time.time() - counters.start_time
    
    with counters.lock:
        table.add_row("📁 Arquivos Processados", str(counters.processed_files))
        table.add_row("📝 Palavras Únicas", str(counters.total_words))
        table.add_row("🧮 Embeddings Gerados", str(counters.processed_embeddings))
        table.add_row("💾 Registros Salvos", str(counters.saved_to_db))
        table.add_row("⚠️ Erros", str(counters.errors))
        table.add_row("⏱️ Tempo Decorrido", f"{elapsed:.2f}s")
        
        if elapsed > 0:
            rate = counters.processed_embeddings / elapsed
            table.add_row("🚀 Taxa de Processamento", f"{rate:.2f}/s")
    
    return table

def generate_progress_table(progress_data: dict) -> Table:
    table = Table(title="📈 Progresso", box=box.ROUNDED)
    table.add_column("Etapa", style="cyan")
    table.add_column("Progresso", justify="right", style="green")
    
    for stage, (current, total) in progress_data.items():
        if total > 0:
            percentage = (current / total) * 100
            table.add_row(stage, f"{percentage:.1f}% ({current}/{total})")
    
    return table

def generate_details_table(recent_actions: list) -> Table:
    table = Table(title="📋 Detalhes Recentes", box=box.ROUNDED)
    table.add_column("Timestamp", style="cyan")
    table.add_column("Ação", style="green")
    table.add_column("Detalhes", style="yellow")
    
    for action in recent_actions[-5:]:  # Mostra últimas 5 ações
        table.add_row(*action)
    
    return table

# Mova estas variáveis para o escopo global
tokenizer = BertTokenizer.from_pretrained('bert-base-uncased')
model = BertModel.from_pretrained('bert-base-uncased')
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
model = model.to(device)


async def process_embeddings_batch_enhanced(words: List[str], progress_callback=None) -> List[np.ndarray]:
    embeddings = []
    for word in words:
        embeddings.append(create_embedding(word))
        if progress_callback:
            await progress_callback()
    return embeddings

# Função auxiliar para processar em chunks menores
async def process_words_in_chunks(words: List[str], chunk_size: int = 1000):
    results = []
    async def progress_callback_async():
        await asyncio.sleep(0)
        console.print(f"Processado chunk {len(results)//chunk_size + 1}/{len(words)//chunk_size + 1}")

    for i in range(0, len(words), chunk_size):
        chunk = words[i:i + chunk_size]
        embeddings = await process_embeddings_batch_enhanced(
            chunk,
            progress_callback_async
        )
        results.extend(embeddings)
    return results

def generate_enhanced_stats_table() -> Table:
    table = Table(title="📊 Métricas Detalhadas", box=box.ROUNDED)
    table.add_column("Categoria", style="cyan")
    table.add_column("Métrica", style="yellow")
    table.add_column("Valor", justify="right", style="green")
    
    with counters.lock:
        # Performance
        elapsed = time.time() - counters.start_time
        rate = counters.processed_embeddings / elapsed if elapsed > 0 else 0
        
        # Métricas de Sistema
        mem_usage = counters.memory_usage[-1] if counters.memory_usage else 0
        cpu_usage = counters.cpu_usage[-1] if counters.cpu_usage else 0
        gpu_usage = counters.gpu_usage[-1] if counters.gpu_usage else 0
        
        # Performance
        table.add_row("Performance", "Taxa de Processamento", f"{rate:.2f}/s")
        table.add_row("Performance", "Tempo Médio por Batch", f"{np.mean(counters.batch_times):.2f}s" if counters.batch_times else "N/A")
        
        # Recursos
        table.add_row("Recursos", "CPU", f"{cpu_usage:.1f}%")
        table.add_row("Recursos", "Memória", f"{mem_usage:.1f}%")
        table.add_row("Recursos", "GPU", f"{gpu_usage:.1f}%")
        
        # Progresso
        table.add_row("Progresso", "Arquivos", f"{counters.processed_files}")
        table.add_row("Progresso", "Palavras", f"{counters.total_words}")
        table.add_row("Progresso", "Embeddings", f"{counters.processed_embeddings}")
        
        # Erros
        error_rate = (counters.errors / counters.processed_embeddings * 100) if counters.processed_embeddings > 0 else 0
        table.add_row("Qualidade", "Taxa de Erro", f"{error_rate:.2f}%")
    
    return table

# Função principal
async def main():
    layout = create_layout()
    progress_data = {
        "Processamento de Arquivos": [0, 0],
        "Geração de Embeddings": [0, 0],
        "Salvamento no Banco": [0, 0]
    }
    recent_actions = []
    
    def add_action(action: str, details: str):
        timestamp = datetime.now().strftime("%H:%M:%S")
        recent_actions.append((timestamp, action, details))
        if len(recent_actions) > 10:
            recent_actions.pop(0)
    
    with Live(layout, refresh_per_second=4) as live:
        # Resto do código principal aqui
        yaml_dir = 'generated-yaml-text-to-embedding'
        conn = setup_database()
        
        yaml_files = [f for f in os.listdir(yaml_dir) if f.endswith('.yaml')]
        progress_data["Processamento de Arquivos"][1] = len(yaml_files)
        
        all_words = set()
        for yaml_file in yaml_files:
            file_path = os.path.join(yaml_dir, yaml_file)
            words = await process_yaml_file(file_path)
            all_words.update(words)
            
            with counters.lock:
                counters.processed_files += 1
                counters.total_words = len(all_words)
                counters.processed_files_list.append(file_path)
            
            progress_data["Processamento de Arquivos"][0] += 1
            add_action("Arquivo Processado", yaml_file)
            
            # Atualiza a visualização
            layout["stats"].update(generate_stats_table())
            layout["progress"].update(generate_progress_table(progress_data))
            layout["details"].update(generate_details_table(recent_actions))
            await asyncio.sleep(0.1) # adicionado para dar tempo de atualizar a tela

        
        # Processar palavras em chunks
        words_list = list(all_words)
        progress_data["Geração de Embeddings"][1] = len(words_list)
        embeddings = await process_words_in_chunks(words_list)
        progress_data["Geração de Embeddings"][0] = len(embeddings)
        
        # Criar DataFrame
        df = pd.DataFrame({
            'word': words_list,
            'embedding': embeddings
        })
        
        # Salvar no banco
        progress_data["Salvamento no Banco"][1] = len(df)
        await save_to_database(df, conn, lambda: update_progress_callback(progress_data, layout, recent_actions))
        
        conn.close()
        add_action("Processo Concluído", "✨ Todos os dados processados!")
        
        # Gera relatório final
        console.print("\n[bold blue]Relatório Final:[/bold blue]")
        console.print(generate_enhanced_stats_table())
        console.print(f"\n[bold blue]Arquivos Processados:[/bold blue]\n{counters.processed_files_list}")
        
        # Calcula o tamanho do banco de dados
        db_size = os.path.getsize('vector-blob-database.db')
        console.print(f"\n[bold blue]Tamanho do Banco de Dados:[/bold blue] {db_size} bytes ({db_size / 1024:.2f} KB)")


def update_progress_callback(progress_data, layout, recent_actions):
    progress_data["Salvamento no Banco"][0] += 1
    with counters.lock:
        counters.saved_to_db += 1
    layout["progress"].update(generate_progress_table(progress_data))
    layout["stats"].update(generate_stats_table())
    layout["details"].update(generate_details_table(recent_actions))
    

if __name__ == "__main__":
    asyncio.run(main())
