import os
import shutil
import hashlib
from datetime import datetime
import pandas as pd

def calcula_hash_arquivo(caminho_arquivo):
    """Calcula o hash SHA-256 do arquivo"""
    hash_sha256 = hashlib.sha256()
    with open(caminho_arquivo, 'rb') as f:
        for bloco in iter(lambda: f.read(4096), b''):
            hash_sha256.update(bloco)
    return hash_sha256.hexdigest()

def coleta_info_arquivos(pasta_origem):
    """Coleta informações dos arquivos .py em todas as subpastas"""
    info_arquivos = []
    
    # Usa os.walk para percorrer recursivamente todas as subpastas
    for raiz, diretorios, arquivos in os.walk(pasta_origem):
        for arquivo in arquivos:
            if arquivo.endswith('.py'):
                caminho_completo = os.path.join(raiz, arquivo)
                stats = os.stat(caminho_completo)
                
                # Calcula caminho relativo para manter a estrutura de pastas
                caminho_relativo = os.path.relpath(caminho_completo, pasta_origem)
                
                info = {
                    'nome': arquivo,
                    'caminho_completo': caminho_completo,
                    'caminho_relativo': caminho_relativo,
                    'data_criacao': datetime.fromtimestamp(stats.st_ctime),
                    'data_modificacao': datetime.fromtimestamp(stats.st_mtime),
                    'hash': calcula_hash_arquivo(caminho_completo)
                }
                info_arquivos.append(info)
    
    return pd.DataFrame(info_arquivos)

def cria_pasta_destino():
    """Cria a pasta de destino se não existir"""
    pasta_destino = 'backup-versionado-restaurado'
    if not os.path.exists(pasta_destino):
        os.makedirs(pasta_destino)
    return pasta_destino

def copia_arquivos_versionados(df, pasta_destino):
    """Copia os arquivos para a pasta de destino com versionamento"""
    # Ordena por data de criação
    df_ordenado = df.sort_values('data_criacao')
    
    # Adiciona número de versão
    versao_inicial = 1
    for idx, row in df_ordenado.iterrows():
        # Separa o nome do arquivo da extensão
        nome_base, extensao = os.path.splitext(row['nome'])
        
        # Cria o novo nome com a versão
        novo_nome = f"{nome_base}----versao--v{versao_inicial:06d}{extensao}"
        
        # Cria a estrutura de pastas necessária
        pasta_final = os.path.join(pasta_destino, os.path.dirname(row['caminho_relativo']))
        if not os.path.exists(pasta_final):
            os.makedirs(pasta_final)
        
        # Caminho completo do arquivo de destino
        caminho_destino = os.path.join(pasta_final, novo_nome)
        
        # Copia o arquivo mantendo os metadados
        shutil.copy2(row['caminho_completo'], caminho_destino)
        versao_inicial += 1
    
    return df_ordenado

def main():
    # Pasta de origem
    pasta_origem = 'backup_restaurado'
    
    # Verifica se a pasta existe
    if not os.path.exists(pasta_origem):
        print(f"Pasta {pasta_origem} não encontrada!")
        return
    
    # Coleta informações dos arquivos
    print("Coletando informações dos arquivos...")
    df_arquivos = coleta_info_arquivos(pasta_origem)
    
    if df_arquivos.empty:
        print("Nenhum arquivo .py encontrado na pasta de origem!")
        return
    
    # Cria pasta de destino
    pasta_destino = cria_pasta_destino()
    
    # Copia arquivos com versionamento
    print("Copiando arquivos...")
    df_final = copia_arquivos_versionados(df_arquivos, pasta_destino)
    
    # Exibe resumo
    print("\nResumo das operações:")
    print(f"Total de arquivos processados: {len(df_final)}")
    print("\nDetalhes dos arquivos:")
    
    # Cria um DataFrame simplificado para exibição
    df_exibicao = df_final[['caminho_relativo', 'data_criacao', 'data_modificacao', 'hash']]
    df_exibicao = df_exibicao.rename(columns={
        'caminho_relativo': 'Arquivo',
        'data_criacao': 'Criação',
        'data_modificacao': 'Modificação',
        'hash': 'Hash'
    })
    
    # Salva o relatório em CSV
    relatorio_path = os.path.join(pasta_destino, 'relatorio_arquivos.csv')
    df_exibicao.to_csv(relatorio_path, index=False)
    
    print(df_exibicao.to_string())
    print(f"\nRelatório detalhado salvo em: {relatorio_path}")

if __name__ == "__main__":
    main()
