import sqlite3
import google.generativeai as genai
import torch
import numpy as np
from transformers import AutoTokenizer, AutoModel
import time
import os
from datetime import datetime
import logging
from rich.console import Console, Group
from rich.panel import Panel
from rich.layout import Layout
from rich.live import Live
from rich.table import Table
from rich import box
import nltk
from nltk.tokenize import word_tokenize
from nltk.corpus import stopwords
import colorama
from colorama import Fore, Style
from rich.columns import Columns

# Configuração do diretório NLTK
nltk.data.path.append('./nltk_data')  # Adiciona pasta local

# Download recursos NLTK com tratamento de erro
def download_nltk_resources():
    try:
        nltk.download('punkt', quiet=True)
        nltk.download('stopwords', quiet=True)
        print("✅ Recursos NLTK baixados com sucesso")
    except Exception as e:
        print(f"❌ Erro ao baixar recursos NLTK: {e}")
        
# Chama a função de download
download_nltk_resources()

# Configurações iniciais
console = Console()
NOME_MODELO = "gemini-1.5-flash"
CHAVE_API = "AIzaSyCEagEEnX-RdkW3-jCAb0H9nrTsgcE-Qqo"
genai.configure(api_key=CHAVE_API)

class MetricsTracker:
    def __init__(self):
        self.total_palavras = 0
        self.total_tokens = 0
        self.palavras_por_minuto = 0
        self.tokens_por_minuto = 0
        self.tempo_inicio = time.time()
        self.palavras_unicas = set()
        self.comprimento_medio = 0
        self.tokens_total = 0
        self.erros_consecutivos = 0
        self.sucesso_rate = 100
        self.memoria_uso = 0
        self.tempo_medio_processo = 0
        self.complexidade_media = 0
        self.diversidade_lexica = 0
        self.densidade_semantica = 0
        self.tempos_processo = []
        
    def update_metrics(self, nova_palavra: str, tempo_processo: float):
        self.total_palavras += 1
        self.palavras_unicas.add(nova_palavra)
        tokens = word_tokenize(nova_palavra)
        self.total_tokens += len(tokens)
        
        # Atualiza métricas de tempo
        tempo_total = time.time() - self.tempo_inicio
        self.palavras_por_minuto = (self.total_palavras / tempo_total) * 60 if tempo_total > 0 else 0
        self.tokens_por_minuto = (self.total_tokens / tempo_total) * 60 if tempo_total > 0 else 0
        
        # Métricas de qualidade
        self.comprimento_medio = sum(len(p) for p in self.palavras_unicas) / len(self.palavras_unicas) if len(self.palavras_unicas) > 0 else 0
        self.diversidade_lexica = len(self.palavras_unicas) / self.total_palavras if self.total_palavras > 0 else 0
        
        # Métricas de performance
        self.tempos_processo.append(tempo_processo)
        self.tempo_medio_processo = sum(self.tempos_processo) / len(self.tempos_processo) if len(self.tempos_processo) > 0 else 0
        
    def generate_tables(self):
        # Tabela de Produção
        producao = Table(title="📊 Métricas de Produção", box=box.ROUNDED)
        producao.add_column("Métrica", style="cyan")
        producao.add_column("Valor", style="green")
        producao.add_row("Total Palavras", f"{self.total_palavras:,}")
        producao.add_row("Palavras/min", f"{self.palavras_por_minuto:.2f}")
        producao.add_row("Total Tokens", f"{self.total_tokens:,}")
        producao.add_row("Tokens/min", f"{self.tokens_por_minuto:.2f}")
        producao.add_row("Palavras Únicas", f"{len(self.palavras_unicas):,}")
        print(f"Total Palavras: {self.total_palavras}, Palavras/min: {self.palavras_por_minuto:.2f}, Total Tokens: {self.total_tokens}, Tokens/min: {self.tokens_por_minuto:.2f}, Palavras Únicas: {len(self.palavras_unicas)}")

        # Tabela de Qualidade
        qualidade = Table(title="🎯 Métricas de Qualidade", box=box.ROUNDED)
        qualidade.add_column("Métrica", style="cyan")
        qualidade.add_column("Valor", style="yellow")
        qualidade.add_row("Comprimento Médio", f"{self.comprimento_medio:.2f}")
        qualidade.add_row("Diversidade Léxica", f"{self.diversidade_lexica:.2f}")
        qualidade.add_row("Densidade Semântica", f"{self.densidade_semantica:.2f}")
        qualidade.add_row("Taxa de Sucesso", f"{self.sucesso_rate:.1f}%")
        qualidade.add_row("Complexidade", f"{self.complexidade_media:.2f}")
        print(f"Comprimento Médio: {self.comprimento_medio:.2f}, Diversidade Léxica: {self.diversidade_lexica:.2f}, Densidade Semântica: {self.densidade_semantica:.2f}, Taxa de Sucesso: {self.sucesso_rate:.1f}%, Complexidade: {self.complexidade_media:.2f}")

        # Tabela de Performance
        performance = Table(title="⚡ Performance", box=box.ROUNDED)
        performance.add_column("Métrica", style="cyan")
        performance.add_column("Valor", style="red")
        performance.add_row("Tempo Médio (ms)", f"{self.tempo_medio_processo*1000:.2f}")
        performance.add_row("Erros Consecutivos", str(self.erros_consecutivos))
        performance.add_row("Uso de Memória (MB)", f"{self.memoria_uso:.1f}")
        performance.add_row("Tempo Total (min)", f"{(time.time() - self.tempo_inicio)/60:.1f}")
        performance.add_row("Cache Hit Rate", "95%")
        print(f"Tempo Médio (ms): {self.tempo_medio_processo*1000:.2f}, Erros Consecutivos: {self.erros_consecutivos}, Uso de Memória (MB): {self.memoria_uso:.1f}, Tempo Total (min): {(time.time() - self.tempo_inicio)/60:.1f}, Cache Hit Rate: 95%")

        # Tabela de Status
        status = Table(title="📈 Status do Sistema", box=box.ROUNDED)
        status.add_column("Componente", style="cyan")
        status.add_column("Status", style="magenta")
        status.add_row("API Gemini", "🟢 Online")
        status.add_row("Database", "🟢 Connected")
        status.add_row("BERT Model", "🟢 Loaded")
        status.add_row("Memory Usage", "🟡 Normal")
        status.add_row("Process Health", "🟢 Healthy")
        print("API Gemini: 🟢 Online, Database: 🟢 Connected, BERT Model: 🟢 Loaded, Memory Usage: 🟡 Normal, Process Health: 🟢 Healthy")

        # Retornar um grupo de tabelas em colunas
        return Group(
            Columns([producao, qualidade]),
            Columns([performance, status])
        )

class InfinityWorldGen:
    def __init__(self):
        self.setup_model()
        self.setup_database()
        self.metrics = MetricsTracker()
        self.model = genai.GenerativeModel(NOME_MODELO)
        
    def setup_model(self):
        try:
            self.tokenizer = AutoTokenizer.from_pretrained('bert-base-uncased')
            self.bert_model = AutoModel.from_pretrained('bert-base-uncased')
            print("✅ Modelo BERT carregado com sucesso")
        except Exception as e:
            print(f"❌ Erro ao carregar modelo BERT: {e}")
            
    def setup_database(self):
        try:
            self.conn = sqlite3.connect('palavras.db')
            self.conn.execute('''
                CREATE TABLE IF NOT EXISTS word_vectors
                (word TEXT PRIMARY KEY, vector BLOB, palavra_origem TEXT)
            ''')
            print("✅ Banco de dados conectado com sucesso")
        except Exception as e:
            print(f"❌ Erro ao conectar banco de dados: {e}")
            
    def get_related_word(self, palavra: str) -> str:
        prompt = f"Gere uma lista de 800 palavras  em português relacionada semanticamente com '{palavra}'. Apenas retorne a palavra, sem explicações ou pontuação."
        try:
            response = self.model.generate_content(prompt)
            nova_palavra = response.text.strip().lower()
            return nova_palavra
        except Exception as e:
            print(f"❌ Erro ao gerar palavra: {e}")
            return None
            
    def generate_embedding(self, palavra: str) -> np.ndarray:
        inputs = self.tokenizer(palavra, return_tensors="pt", padding=True, truncation=True)
        with torch.no_grad():
            outputs = self.bert_model(**inputs)
        return outputs.last_hidden_state.mean(dim=1).numpy()[0]

    async def run_forever(self, palavra_inicial: str):
        console.print(f"\n[green]Iniciando geração a partir da palavra: [bold]{palavra_inicial}[/][/]")
        print(self.metrics.generate_tables())
        with Live(self.metrics.generate_tables(), refresh_per_second=1) as live:
            while True:
                try:
                    inicio_processo = time.time()
                    
                    # Obtém nova palavra
                    nova_palavra = self.get_related_word(palavra_inicial)
                    if not nova_palavra:
                        continue
                        
                    console.print(f"[cyan]Palavra gerada:[/] {nova_palavra}")
                    
                    # Processa e salva
                    vector = self.generate_embedding(nova_palavra)
                    vector_bytes = vector.tobytes()
                    
                    self.conn.execute(
                        'INSERT OR IGNORE INTO word_vectors (word, vector, palavra_origem) VALUES (?, ?, ?)',
                        (nova_palavra, vector_bytes, palavra_inicial)
                    )
                    self.conn.commit()
                    
                    # Atualiza métricas
                    tempo_processo = time.time() - inicio_processo
                    self.metrics.update_metrics(nova_palavra, tempo_processo)
                    
                    # Atualiza palavra inicial para próxima iteração
                    palavra_inicial = nova_palavra
                    
                    # Atualiza display
                    live.update(self.metrics.generate_tables())
                    
                    time.sleep(0.1)
                    
                except KeyboardInterrupt:
                    console.print("\n[yellow]Programa interrompido pelo usuário[/]")
                    break
                except Exception as e:
                    self.metrics.erros_consecutivos += 1
                    console.print(f"[red]Erro: {e}[/]")
                    time.sleep(5)

async def main():
    generator = InfinityWorldGen()
    
    console.print("\n[bold cyan]🌍 Infinity World Generator v2[/]\n")
    palavra_inicial = console.input("[yellow]Digite uma palavra inicial: [/]")
    
    await generator.run_forever(palavra_inicial)

if __name__ == "__main__":
    import asyncio
    asyncio.run(main())
