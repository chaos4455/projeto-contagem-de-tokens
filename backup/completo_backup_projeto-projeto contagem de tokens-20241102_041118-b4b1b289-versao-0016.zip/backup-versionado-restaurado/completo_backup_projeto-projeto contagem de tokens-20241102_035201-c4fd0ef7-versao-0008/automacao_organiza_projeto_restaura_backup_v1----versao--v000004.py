import os
import shutil
from pathlib import Path
import subprocess
import time
from rich.console import Console
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn
from rich.table import Table
import hashlib
from datetime import datetime
import logging

class AutomacaoBackup:
    def __init__(self):
        self.console = Console()
        self.pasta_raiz = Path(".")
        self.estatisticas = {
            'arquivos_movidos': 0,
            'arquivos_renomeados': 0,
            'zips_organizados': 0
        }
        self.setup_pastas()
        self.setup_logging()

    def setup_logging(self):
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(levelname)s - %(message)s',
            handlers=[
                logging.FileHandler('automacao_backup.log'),
                logging.StreamHandler()
            ]
        )

    def setup_pastas(self):
        """Cria as pastas necessárias se não existirem"""
        pastas = ['logs', 'txt', 'json', 'zip']
        for pasta in pastas:
            Path(pasta).mkdir(exist_ok=True)

    def gerar_hash_unico(self, arquivo: Path) -> str:
        """Gera um hash único baseado no nome do arquivo e timestamp"""
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        hash_base = f"{arquivo.stem}_{timestamp}"
        return hashlib.md5(hash_base.encode()).hexdigest()[:8]

    def mover_arquivo_com_verificacao(self, arquivo: Path, pasta_destino: Path) -> bool:
        """Move arquivo para destino, tratando duplicatas com hash único"""
        try:
            nome_arquivo = arquivo.name
            caminho_destino = pasta_destino / nome_arquivo

            if caminho_destino.exists():
                # Gera novo nome com hash
                hash_unico = self.gerar_hash_unico(arquivo)
                novo_nome = f"{arquivo.stem}_{hash_unico}{arquivo.suffix}"
                caminho_destino = pasta_destino / novo_nome
                self.estatisticas['arquivos_renomeados'] += 1
                self.console.print(f"[yellow]⚠️ Arquivo renomeado: {novo_nome}[/]")

            shutil.move(str(arquivo), str(caminho_destino))
            self.estatisticas['arquivos_movidos'] += 1
            return True

        except Exception as e:
            logging.error(f"Erro ao mover {arquivo}: {e}")
            self.console.print(f"[red]❌ Erro ao mover {arquivo}: {str(e)}[/]")
            return False

    def organizar_arquivos(self):
        """Organiza os arquivos por extensão"""
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            transient=True,
        ) as progress:
            task = progress.add_task("[cyan]Organizando arquivos...", total=None)
            
            extensoes = {
                '.log': 'logs',
                '.txt': 'txt',
                '.json': 'json',
                '.zip': 'zip'
            }

            # Lista todos os arquivos antes de começar a mover
            arquivos_para_mover = []
            for arquivo in self.pasta_raiz.glob('*'):
                if arquivo.is_file():
                    ext = arquivo.suffix.lower()
                    if ext in extensoes:
                        arquivos_para_mover.append((arquivo, extensoes[ext]))

            # Move os arquivos
            for arquivo, pasta_destino in arquivos_para_mover:
                if arquivo.suffix.lower() == '.zip':
                    self.estatisticas['zips_organizados'] += 1
                self.mover_arquivo_com_verificacao(arquivo, Path(pasta_destino))

            progress.update(task, completed=True)
            self.mostrar_estatisticas_organizacao()

    def mostrar_estatisticas_organizacao(self):
        table = Table(title="📊 Estatísticas de Organização")
        table.add_column("Métrica", style="cyan")
        table.add_column("Quantidade", justify="right", style="green")

        table.add_row("Arquivos Movidos", str(self.estatisticas['arquivos_movidos']))
        table.add_row("Arquivos Renomeados", str(self.estatisticas['arquivos_renomeados']))
        table.add_row("ZIPs Organizados", str(self.estatisticas['zips_organizados']))

        self.console.print(table)

    def executar_script(self, nome_script, descricao):
        """Executa um script Python e monitora sua execução"""
        self.console.print(f"\n[bold blue]🚀 Executando: {descricao}[/]")
        
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            transient=True,
        ) as progress:
            task = progress.add_task(f"[cyan]Processando {nome_script}...", total=None)
            
            try:
                resultado = subprocess.run(
                    f'python "{nome_script}"',
                    shell=True,
                    capture_output=True,
                    text=True,
                    encoding='utf-8',
                    errors='ignore'
                )
                
                if resultado.returncode == 0:
                    self.console.print(f"[green]✅ {descricao} concluído com sucesso![/]")
                    if resultado.stdout.strip():
                        self.console.print("[dim]Saída do script:[/]")
                        self.console.print(resultado.stdout)
                else:
                    self.console.print(f"[red]❌ Erro ao executar {descricao}[/]")
                    if resultado.stderr.strip():
                        self.console.print(f"[red]Erro: {resultado.stderr}[/]")
                
                progress.update(task, completed=True)
                return resultado.returncode == 0
                
            except Exception as e:
                self.console.print(f"[red]❌ Erro ao executar {nome_script}: {str(e)}[/]")
                logging.error(f"Erro na execução de {nome_script}: {str(e)}")
                progress.update(task, completed=True)
                return False

    def mostrar_sumario_final(self, sucessos, total):
        table = Table(title="📑 Sumário Final de Execução")
        table.add_column("Métrica", style="cyan")
        table.add_column("Valor", justify="right", style="green")

        table.add_row("Scripts Executados", str(total))
        table.add_row("Sucessos", str(sucessos))
        table.add_row("Falhas", str(total - sucessos))
        table.add_row("Taxa de Sucesso", f"{(sucessos/total)*100:.1f}%")
        table.add_row("Arquivos Organizados", str(self.estatisticas['arquivos_movidos']))
        table.add_row("ZIPs Processados", str(self.estatisticas['zips_organizados']))

        self.console.print(table)

    def executar_automacao(self):
        self.console.print(Panel(
            "[bold yellow]Automação de Backup e Restauração[/]\n"
            f"📅 Data: {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}\n"
            "🔄 Sistema de Organização e Backup Automatizado",
            border_style="blue"
        ))
        
        # Lista de scripts para executar em ordem
        scripts = [
            ("backup.py", "Backup inicial"),
            ("restaurar_backup.py", "Restauração de backup"),
            ("remover_duplicados.py", "Remoção de duplicados"),
            ("limpar_duplicados_avancado.py", "Limpeza avançada")
        ]

        # Primeiro organiza os arquivos
        self.console.print("\n[bold yellow]🗂 Iniciando organização de arquivos...[/]")
        self.organizar_arquivos()

        # Executa cada script em sequência
        sucessos = 0
        for script, descricao in scripts:
            if self.executar_script(script, descricao):
                sucessos += 1
            time.sleep(1)  # Pequena pausa entre scripts

        # Mostra sumário final
        self.mostrar_sumario_final(sucessos, len(scripts))

def main():
    automacao = AutomacaoBackup()
    automacao.executar_automacao()

if __name__ == "__main__":
    main()
