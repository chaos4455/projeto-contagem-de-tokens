import sqlite3
import google.generativeai as genai
import torch
import numpy as np
from transformers import AutoTokenizer, AutoModel
import time
import os
from datetime import datetime
import logging
from rich.console import Console, Group
from rich.panel import Panel
from rich.layout import Layout
from rich.live import Live
from rich.table import Table
from rich import box
import nltk
from nltk.tokenize import word_tokenize
from nltk.corpus import stopwords
import colorama
from colorama import Fore, Style
from rich.columns import Columns
import pandas as pd
import matplotlib.pyplot as plt

# Configuração do diretório NLTK
nltk.data.path.append('./nltk_data')  # Adiciona pasta local

# Download recursos NLTK com tratamento de erro
def download_nltk_resources():
    try:
        nltk.download('punkt', quiet=True)
        nltk.download('stopwords', quiet=True)
        print("✅ Recursos NLTK baixados com sucesso")
    except Exception as e:
        print(f"❌ Erro ao baixar recursos NLTK: {e}")
        
# Chama a função de download
download_nltk_resources()

# Configurações iniciais
console = Console()
NOME_MODELO = "gemini-1.5-flash"
CHAVE_API = "AIzaSyCEagEEnX-RdkW3-jCAb0H9nrTsgcE-Qqo"
genai.configure(api_key=CHAVE_API)

class MetricsTracker:
    def __init__(self):
        self.total_palavras = 0
        self.total_tokens = 0
        self.palavras_por_minuto = 0
        self.tokens_por_minuto = 0
        self.tempo_inicio = time.time()
        self.palavras_unicas = set()
        self.comprimento_medio = 0
        self.tokens_total = 0
        self.erros_consecutivos = 0
        self.sucesso_rate = 100
        self.memoria_uso = 0
        self.tempo_medio_processo = 0
        self.complexidade_media = 0
        self.diversidade_lexica = 0
        self.densidade_semantica = 0
        self.tempos_processo = []
        self.df_palavras = pd.DataFrame(columns=['palavra', 'timestamp', 'tamanho', 'tokens'])

    def update_metrics(self, df_epoca: pd.DataFrame):
        """Atualiza métricas baseado no DataFrame da época"""
        # Métricas de volume
        self.total_palavras += len(df_epoca)
        self.palavras_unicas.update(df_epoca['palavra'])
        self.total_tokens += df_epoca['tokens'].sum()
        
        # Métricas de tempo
        tempo_total = time.time() - self.tempo_inicio
        self.palavras_por_minuto = (self.total_palavras / tempo_total) * 60 if tempo_total > 0 else 0
        self.tokens_por_minuto = (self.total_tokens / tempo_total) * 60 if tempo_total > 0 else 0
        
        # Métricas de qualidade
        self.comprimento_medio = df_epoca['tamanho'].mean()
        self.diversidade_lexica = len(self.palavras_unicas) / self.total_palavras if self.total_palavras > 0 else 0
        
        # Métricas de performance
        self.tempos_processo.extend(df_epoca['tempo_processamento'].tolist())
        self.tempo_medio_processo = np.mean(self.tempos_processo) if len(self.tempos_processo) > 0 else 0
        
        # Adiciona as novas linhas ao DataFrame
        self.df_palavras = pd.concat([self.df_palavras, df_epoca], ignore_index=True)

    def generate_tables(self):
        # Tabela de Produção
        producao = Table(title="📊 Métricas de Produção", box=box.ROUNDED)
        producao.add_column("Métrica", style="cyan")
        producao.add_column("Valor", style="green")
        producao.add_row("Total Palavras", f"{self.total_palavras:,}")
        producao.add_row("Palavras/min", f"{self.palavras_por_minuto:.2f}")
        producao.add_row("Total Tokens", f"{self.total_tokens:,}")
        producao.add_row("Tokens/min", f"{self.tokens_por_minuto:.2f}")
        producao.add_row("Palavras Únicas", f"{len(self.palavras_unicas):,}")

        # Tabela de Qualidade
        qualidade = Table(title="🎯 Métricas de Qualidade", box=box.ROUNDED)
        qualidade.add_column("Métrica", style="cyan")
        qualidade.add_column("Valor", style="yellow")
        qualidade.add_row("Comprimento Médio", f"{self.comprimento_medio:.2f}")
        qualidade.add_row("Diversidade Léxica", f"{self.diversidade_lexica:.2f}")

        # Tabela de Performance
        performance = Table(title="⚡ Performance", box=box.ROUNDED)
        performance.add_column("Métrica", style="cyan")
        performance.add_column("Valor", style="red")
        performance.add_row("Tempo Médio (ms)", f"{self.tempo_medio_processo*1000:.2f}")

        # Retornar um grupo de tabelas em colunas
        return Group(
            Columns([producao, qualidade]),
            Columns([performance])
        )

    def plot_metrics(self):
        if not self.df_palavras.empty:
            plt.figure(figsize=(12, 6))

            # Plot 1: Comprimento médio das palavras ao longo do tempo
            plt.subplot(2, 2, 1)
            plt.plot(self.df_palavras['timestamp'], self.df_palavras['tamanho'])
            plt.title('Comprimento Médio das Palavras')
            plt.xlabel('Tempo')
            plt.ylabel('Comprimento (caracteres)')

            # Plot 2: Número de tokens por palavra ao longo do tempo
            plt.subplot(2, 2, 2)
            plt.plot(self.df_palavras['timestamp'], self.df_palavras['tokens'])
            plt.title('Número de Tokens por Palavra')
            plt.xlabel('Tempo')
            plt.ylabel('Número de Tokens')

            # Plot 3: Histograma do comprimento das palavras
            plt.subplot(2, 2, 3)
            plt.hist(self.df_palavras['tamanho'], bins=20)
            plt.title('Histograma do Comprimento das Palavras')
            plt.xlabel('Comprimento (caracteres)')
            plt.ylabel('Frequência')

            # Plot 4: Histograma do número de tokens por palavra
            plt.subplot(2, 2, 4)
            plt.hist(self.df_palavras['tokens'], bins=20)
            plt.title('Histograma do Número de Tokens por Palavra')
            plt.xlabel('Número de Tokens')
            plt.ylabel('Frequência')

            plt.tight_layout()
            plt.show()


class InfinityWorldGen:
    def __init__(self):
        self.setup_model()
        self.setup_database()
        self.metrics = MetricsTracker()
        self.model = genai.GenerativeModel(NOME_MODELO)
        self.current_stream = None
        self.current_word_count = 0
        self.epoca_atual = 1
        self.chars_processados = 0
        self.tokens_processados = 0
        
    def setup_model(self):
        try:
            self.tokenizer = AutoTokenizer.from_pretrained('bert-base-uncased')
            self.bert_model = AutoModel.from_pretrained('bert-base-uncased')
            print("✅ Modelo BERT carregado com sucesso")
        except Exception as e:
            print(f"❌ Erro ao carregar modelo BERT: {e}")
            
    def setup_database(self):
        try:
            self.conn = sqlite3.connect('palavras.db')
            self.conn.execute('''
                CREATE TABLE IF NOT EXISTS word_vectors
                (word TEXT PRIMARY KEY, vector BLOB, palavra_origem TEXT)
            ''')
            print("✅ Banco de dados conectado com sucesso")
        except Exception as e:
            print(f"❌ Erro ao conectar banco de dados: {e}")
            
    def get_related_word(self, palavra: str) -> str:
        prompt = f"Gere uma lista de 800 palavras  em português relacionada semanticamente com '{palavra}'. Apenas retorne a palavra, sem explicações ou pontuação."
        try:
            response = self.model.generate_content(prompt)
            nova_palavra = response.text.strip().lower()
            return nova_palavra
        except Exception as e:
            print(f"❌ Erro ao gerar palavra: {e}")
            return None
            
    def generate_embedding(self, palavra: str) -> np.ndarray:
        inputs = self.tokenizer(palavra, return_tensors="pt", padding=True, truncation=True)
        with torch.no_grad():
            outputs = self.bert_model(**inputs)
        return outputs.last_hidden_state.mean(dim=1).numpy()[0]

    async def process_stream(self, stream) -> str:
        """Processa o stream de resposta da IA em tempo real"""
        palavras_completas = []
        buffer = ""
        
        try:
            async for chunk in stream:
                if not chunk.text:
                    continue
                    
                buffer += chunk.text
                palavras = buffer.split()
                
                if palavras:
                    # Processa palavras completas
                    for palavra in palavras[:-1]:  # Exceto última que pode estar incompleta
                        palavra = palavra.strip().lower()
                        if palavra:
                            palavras_completas.append(palavra)
                            self.current_word_count += 1
                            console.print(f"[cyan]Palavra processada ({self.current_word_count}): [/]{palavra}")
                    
                    buffer = palavras[-1]  # Mantém última palavra possivelmente incompleta
                
                # Atualiza métricas em tempo real
                if palavras_completas:
                    self.metrics.update_stream_metrics(len(palavras_completas))
                    
            # Processa buffer final se houver
            if buffer.strip():
                palavras_completas.append(buffer.strip().lower())
                
            return " ".join(palavras_completas)
            
        except Exception as e:
            console.print(f"[red]Erro no processamento do stream: {e}[/]")
            return None

    async def get_related_word(self, palavra: str) -> str:
        """Versão melhorada com processamento de stream"""
        prompt = f"""
        Gere uma lista palavra1, frase2, palavra3, etc gere 200 palavras ou frases
          -  em português relacionada semanticamente com '{palavra}'.
        Regras:
        - Apenas retorne a palavra, sem explicações
        - Sem pontuação ou formatação adicional
        - A palavra deve ter relação clara com o contexto de '{palavra}'
        - Evite repetições de palavras já geradas
        """
        
        try:
            self.current_word_count = 0
            response = self.model.generate_content(
                prompt,
                stream=True,
                generation_config={
                    "temperature": 0.9,
                    "top_p": 0.8,
                    "top_k": 40,
                }
            )
            
            palavras_processadas = []
            buffer = ""
            
            for chunk in response:
                if not chunk.text:
                    continue
                    
                # Adiciona chunk ao buffer
                buffer += chunk.text
                
                # Processa palavras completas (separadas por vírgula)
                if "," in buffer:
                    partes = buffer.split(",")
                    # Processa todas exceto a última (que pode estar incompleta)
                    for palavra in partes[:-1]:
                        palavra_limpa = palavra.strip().lower()
                        if palavra_limpa:
                            self.current_word_count += 1
                            console.print(f"[cyan]#{self.current_word_count} Stream: [/]{palavra_limpa}")
                            palavras_processadas.append(palavra_limpa)
                            # Atualiza métricas em tempo real
                            self.metrics.update_metrics(palavra_limpa, time.time())
                    
                    # Mantém a última parte no buffer
                    buffer = partes[-1]
            
            # Processa o buffer final
            if buffer.strip():
                palavra_final = buffer.strip().lower()
                if palavra_final:
                    self.current_word_count += 1
                    console.print(f"[cyan]#{self.current_word_count} Final: [/]{palavra_final}")
                    palavras_processadas.append(palavra_final)
                    self.metrics.update_metrics(palavra_final, time.time())
            
            # Retorna a primeira palavra processada para continuar o pipeline
            return palavras_processadas[0] if palavras_processadas else None
            
        except Exception as e:
            console.print(f"[red]Erro na geração: {e}[/]")
            return None

    async def process_pipeline(self, palavra: str):
        """Processa um pipeline completo para uma palavra"""
        console.print(f"\n[bold blue]🔄 Iniciando pipeline para: {palavra}[/]")
        
        try:
            # 1. Geração com streaming
            inicio_geracao = time.time()
            console.print("[yellow]Iniciando geração de stream...[/]")
            nova_palavra = await self.get_related_word(palavra)
            tempo_geracao = time.time() - inicio_geracao
            
            if not nova_palavra:
                console.print("[red]❌ Falha na geração da palavra[/]")
                return None
                
            # 2. Embedding
            inicio_embedding = time.time()
            console.print(f"[yellow]Gerando embedding para: {nova_palavra}[/]")
            vector = self.generate_embedding(nova_palavra)
            tempo_embedding = time.time() - inicio_embedding
            
            # 3. Armazenamento
            inicio_storage = time.time()
            console.print("[yellow]Salvando no banco de dados...[/]")
            vector_bytes = vector.tobytes()
            self.conn.execute(
                'INSERT OR IGNORE INTO word_vectors (word, vector, palavra_origem) VALUES (?, ?, ?)',
                (nova_palavra, vector_bytes, palavra)
            )
            self.conn.commit()
            tempo_storage = time.time() - inicio_storage
            
            # Métricas detalhadas do pipeline
            console.print(f"""[green]✅ Pipeline completo:[/]
            📝 Palavra processada: {nova_palavra}
            ⏱️ Tempo geração: {tempo_geracao:.2f}s
            🧮 Tempo embedding: {tempo_embedding:.2f}s
            💾 Tempo storage: {tempo_storage:.2f}s
            ⌛ Tempo total: {(tempo_geracao + tempo_embedding + tempo_storage):.2f}s
            """)
            
            return nova_palavra
            
        except Exception as e:
            console.print(f"[red]❌ Erro no pipeline: {e}[/]")
            return None

    async def run_forever(self, palavra_inicial: str):
        console.print("\n[bold cyan]🌍 Infinity World Generator v2[/]")
        palavra_atual = palavra_inicial
        
        while True:
            try:
                df_epoca = await self.process_stream_to_df(palavra_atual)
                if df_epoca is not None:
                    # Atualiza métricas com dados da época
                    self.metrics.update_metrics(df_epoca)
                    # Plota as métricas
                    self.metrics.plot_metrics()
                    # Escolhe próxima palavra aleatoriamente do DataFrame
                    palavra_atual = df_epoca['palavra'].sample().iloc[0]
                    time.sleep(1)  # Pequena pausa entre épocas
                    
            except KeyboardInterrupt:
                console.print("\n[yellow]Programa interrompido pelo usuário[/]")
                break
            except Exception as e:
                console.print(f"[red]Erro: {e}[/]")
                time.sleep(5)

    async def process_stream_to_df(self, palavra_origem: str) -> pd.DataFrame:
        """Processa uma época completa do stream da IA"""
        prompt = f"""
        Gere uma lista de palavras e frases separadas por vírgula (palavra1, frase2, palavra3, etc)
        relacionadas semanticamente com '{palavra_origem}'.
        Gere pelo menos 200 itens relacionados.
        Apenas retorne a lista, sem explicações ou pontuação adicional.
        """
        
        console.print(f"\n[bold cyan]🔄 Iniciando Época {self.epoca_atual}[/]")
        console.print(f"[yellow]Palavra origem: {palavra_origem}[/]")
        
        try:
            inicio_epoca = time.time()
            buffer = ""
            contador_palavras = 0
            df_epoca = pd.DataFrame(columns=['palavra', 'timestamp', 'tamanho', 'tokens', 'tempo_processamento'])
            
            with Live() as live:
                response = self.model.generate_content(
                    prompt,
                    stream=True,
                    generation_config={
                        "temperature": 0.9,
                        "top_p": 0.8,
                        "top_k": 40,
                    }
                )
                
                for chunk in response:
                    if not chunk.text:
                        continue
                        
                    buffer += chunk.text
                    self.chars_processados += len(chunk.text)
                    
                    # Cria nova tabela de status
                    status_table = Table(title="Status do Processamento", box=box.ROUNDED)
                    status_table.add_column("Métrica", style="cyan")
                    status_table.add_column("Valor", style="yellow")
                    status_table.add_row("Época", str(self.epoca_atual))
                    status_table.add_row("Processando", palavra_origem)
                    status_table.add_row("Caracteres", f"{self.chars_processados:,}")
                    status_table.add_row("Palavras", str(contador_palavras))
                    status_table.add_row("Tempo", f"{time.time() - inicio_epoca:.1f}s")
                    
                    # Atualiza o display
                    live.update(status_table)
                    
                    # Processa palavras completas quando encontra vírgulas
                    if "," in buffer:
                        partes = buffer.split(",")
                        for parte in partes[:-1]:
                            palavra = parte.strip()
                            if palavra:
                                contador_palavras += 1
                                tokens = len(word_tokenize(palavra))
                                self.tokens_processados += tokens
                                
                                # Adiciona ao DataFrame
                                nova_linha = {
                                    'palavra': palavra,
                                    'timestamp': datetime.now(),
                                    'tamanho': len(palavra),
                                    'tokens': tokens,
                                    'tempo_processamento': time.time() - inicio_epoca
                                }
                                
                                df_epoca = pd.concat([df_epoca, pd.DataFrame([nova_linha])], ignore_index=True)
                                
                        buffer = partes[-1]
                
                # Processa buffer final
                if buffer.strip():
                    palavra_final = buffer.strip()
                    if palavra_final:
                        contador_palavras += 1
                        tokens = len(word_tokenize(palavra_final))
                        self.tokens_processados += tokens
                        
                        nova_linha = {
                            'palavra': palavra_final,
                            'timestamp': datetime.now(),
                            'tamanho': len(palavra_final),
                            'tokens': tokens,
                            'tempo_processamento': time.time() - inicio_epoca
                        }
                        
                        df_epoca = pd.concat([df_epoca, pd.DataFrame([nova_linha])], ignore_index=True)
            
            # Relatório final da época
            tempo_total = time.time() - inicio_epoca
            
            console.print(f"""
            [bold green]✅ Época {self.epoca_atual} Completa![/]
            📊 Estatísticas:
            • Palavras processadas: {len(df_epoca):,}
            • Caracteres totais: {self.chars_processados:,}
            • Tokens totais: {self.tokens_processados:,}
            • Tempo total: {tempo_total:.1f}s
            • Palavras/segundo: {len(df_epoca)/tempo_total:.1f}
            • Tamanho médio: {df_epoca['tamanho'].mean():.1f} chars
            • Tokens médios: {df_epoca['tokens'].mean():.1f}
            """)
            
            self.epoca_atual += 1
            return df_epoca
            
        except Exception as e:
            console.print(f"[red]Erro no processamento da época: {e}[/]")
            return None

    def update_metrics(self, palavra: str, tempo_processo: float, df_atual: pd.DataFrame):
        """Versão atualizada para trabalhar com DataFrame"""
        self.total_palavras = len(df_atual)
        self.palavras_unicas = len(df_atual['palavra'].unique())
        self.tempo_medio_processo = df_atual['tempo_processamento'].mean()
        self.comprimento_medio = df_atual['tamanho'].mean()
        
        # Calcula palavras por minuto baseado no DataFrame
        tempo_total = time.time() - self.tempo_inicio
        self.palavras_por_minuto = (self.total_palavras / tempo_total) * 60 if tempo_total > 0 else 0
        
        # Atualiza outras métricas existentes...
        self.diversidade_lexica = self.palavras_unicas / self.total_palavras if self.total_palavras > 0 else 0
        
        # Gera relatório em tempo real
        self.metrics.generate_tables()

async def main():
    generator = InfinityWorldGen()
    
    console.print("\n[bold cyan]🌍 Infinity World Generator v2[/]\n")
    palavra_inicial = console.input("[yellow]Digite uma palavra inicial: [/]")
    
    await generator.run_forever(palavra_inicial)

if __name__ == "__main__":
    import asyncio
    asyncio.run(main())
