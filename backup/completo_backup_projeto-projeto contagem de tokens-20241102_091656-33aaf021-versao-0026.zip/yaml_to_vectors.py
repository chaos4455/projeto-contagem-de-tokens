import yaml
import torch
from transformers import BertTokenizer, BertModel
import sqlite3
import numpy as np
from pathlib import Path
from tqdm import tqdm
import re
from rich import print
from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich.progress import track
import time
import psutil
import os

console = Console()

class YAMLVectorizer:
    def __init__(self):
        # Inicializa BERT
        self.tokenizer = BertTokenizer.from_pretrained('bert-base-uncased')
        self.model = BertModel.from_pretrained('bert-base-uncased')
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        self.model.to(self.device)
        self.model.eval()
        
        # Inicializa banco
        self.setup_database()
    
    def setup_database(self):
        """Configura banco SQLite"""
        self.conn = sqlite3.connect('vectors.db')
        self.conn.execute('''
            CREATE TABLE IF NOT EXISTS word_vectors (
                id INTEGER PRIMARY KEY,
                word TEXT UNIQUE,
                vector BLOB
            )
        ''')
        self.conn.commit()
    
    def clean_text(self, text: str) -> str:
        """Limpa e normaliza texto"""
        text = re.sub(r'```.*?```', '', text, flags=re.DOTALL)  # Remove blocos código
        text = re.sub(r'http\S+', '', text)  # Remove URLs
        text = re.sub(r'[^\w\s]', ' ', text)  # Remove caracteres especiais
        return ' '.join(text.lower().split())
    
    def extract_words(self, yaml_content: dict) -> set:
        """Extrai palavras únicas do YAML"""
        words = set()
        
        def process_item(item):
            if isinstance(item, str):
                text = self.clean_text(item)
                words.update(word for word in text.split() 
                           if len(word) >= 2 and not word.isnumeric())
            elif isinstance(item, dict):
                for value in item.values():
                    process_item(value)
            elif isinstance(item, list):
                for value in item:
                    process_item(value)
        
        process_item(yaml_content)
        return words
    
    def count_tokens(self, text: str) -> int:
        """Conta tokens usando BERT tokenizer"""
        return len(self.tokenizer.tokenize(text))

    def count_words(self, text: str) -> int:
        """Conta palavras no texto"""
        return len(self.clean_text(text).split())

    def generate_embedding(self, word: str) -> np.ndarray:
        """Gera embedding para uma palavra"""
        with torch.no_grad():
            inputs = self.tokenizer(word, return_tensors='pt', padding=True).to(self.device)
            outputs = self.model(**inputs)
            embedding = outputs.last_hidden_state.mean(dim=1).cpu().numpy()[0]
            return embedding
    
    def process_file(self, yaml_path: Path):
        """Processa um arquivo YAML"""
        try:
            # Carrega e extrai palavras do YAML
            with open(yaml_path) as f:
                content = yaml.safe_load(f)
            words = self.extract_words(content)
            text_content = yaml.safe_dump(content) # Pega o texto do YAML para contagem

            # Gera e salva embeddings
            cursor = self.conn.cursor()
            embeddings = []
            for word in words:
                # Verifica se palavra já existe
                if not cursor.execute('SELECT 1 FROM word_vectors WHERE word = ?', (word,)).fetchone():
                    # Gera e salva embedding
                    vector = self.generate_embedding(word)
                    embeddings.append(vector)
                    cursor.execute(
                        'INSERT INTO word_vectors (word, vector) VALUES (?, ?)',
                        (word, vector.tobytes())
                    )
            
            self.conn.commit()
            return len(words), self.count_tokens(text_content), self.count_words(text_content), embeddings
            
        except Exception as e:
            print(f"Erro ao processar {yaml_path}: {e}")
            return 0,0,0,[]

    def get_system_info(self):
        """Coleta informações do sistema"""
        cpu_percent = psutil.cpu_percent(interval=1, percpu=True)
        cpu_total = psutil.cpu_percent(interval=1)
        mem = psutil.virtual_memory()
        return cpu_percent, cpu_total, mem

    def get_bert_info(self):
        """Coleta informações do modelo BERT"""
        return self.model.config.name_or_path, self.model.config.hidden_size, 0.8 # Temperatura arbitrária

    def calculate_embedding_density(self, embeddings):
        if not embeddings:
            return 0.0
        return np.mean(np.linalg.norm(embeddings, axis=1))

    def calculate_embedding_stats(self, embeddings):
        if not embeddings:
            return {}, 0, 0
        embeddings_np = np.array(embeddings)
        mean = np.mean(embeddings_np, axis=0)
        std = np.std(embeddings_np, axis=0)
        min_norm = np.min(np.linalg.norm(embeddings_np, axis=1))
        max_norm = np.max(np.linalg.norm(embeddings_np, axis=1))
        return {"mean": mean.tolist(), "std": std.tolist()}, min_norm, max_norm


    def process_directory(self, yaml_dir: str):
        """Processa diretório de YAMLs"""
        yaml_files = list(Path(yaml_dir).glob('*.yaml'))
        total_words = 0
        total_tokens = 0
        total_unique_words = 0
        start_time = time.time()
        all_embeddings = []
        
        print(f"Processando {len(yaml_files)} arquivos YAML...")
        for yaml_file in track(yaml_files, description="Processando arquivos..."):
            unique_words, tokens, words, embeddings = self.process_file(yaml_file)
            total_words += words
            total_tokens += tokens
            total_unique_words += unique_words
            all_embeddings.extend(embeddings)

        end_time = time.time()
        elapsed_time = end_time - start_time
        cpu_percent, cpu_total, mem = self.get_system_info()
        model_name, model_dim, temperature = self.get_bert_info()
        embedding_density = self.calculate_embedding_density(np.array(all_embeddings))
        embedding_stats, min_norm, max_norm = self.calculate_embedding_stats(all_embeddings)
        self.display_kpis(total_unique_words, total_tokens, total_words, len(yaml_files), elapsed_time, cpu_percent, cpu_total, mem, model_name, model_dim, temperature, embedding_density, embedding_stats, min_norm, max_norm)

    def display_kpis(self, unique_words, tokens, words, files_processed, elapsed_time, cpu_percent, cpu_total, mem, model_name, model_dim, temperature, embedding_density, embedding_stats, min_norm, max_norm):
        def create_grid(title, data):
            table = Table(title=title)
            for key in data:
                table.add_column(key)
            table.add_row(*[str(val) for val in data.values()])
            return table

        # Grid 1: Métricas de Texto
        grid1 = create_grid("Análise Textual", {
            "Palavras Únicas": unique_words,
            "Tokens Totais": tokens,
            "Palavras Totais": words,
            "Razão Token/Palavra": round(tokens/words if words > 0 else 0, 2),
            "Densidade Léxica": round(unique_words/words if words > 0 else 0, 2),
            "Arquivos Processados": files_processed,
            "Média Tokens/Arquivo": round(tokens/files_processed if files_processed > 0 else 0, 2),
            "Média Palavras/Arquivo": round(words/files_processed if files_processed > 0 else 0, 2),
            "Complexidade Vocabular": round(unique_words/files_processed if files_processed > 0 else 0, 2),
            "Taxa Compressão": round(unique_words/(tokens + 1), 3)
        })

        # Grid 2: Métricas de Embedding
        grid2 = create_grid("Análise de Embeddings", {
            "Dimensionalidade": model_dim,
            "Densidade Média": round(embedding_density, 3),
            "Norma Mínima": round(min_norm, 3),
            "Norma Máxima": round(max_norm, 3),
            "Amplitude Norma": round(max_norm - min_norm, 3),
            "Desvio Padrão Médio": round(np.mean(embedding_stats.get("std", [0])) if embedding_stats else 0, 3),
            "Média Global": round(np.mean(embedding_stats.get("mean", [0])) if embedding_stats else 0, 3),
            "Dispersão Vetorial": round(np.std(embedding_stats.get("std", [0])) if embedding_stats else 0, 3),
            "Coeficiente Variação": round(np.std(embedding_stats.get("std", [0]))/np.mean(embedding_stats.get("mean", [1])) if embedding_stats and np.mean(embedding_stats.get("mean", [1])) != 0 else 0, 3),
            "Entropia Embedding": round(-np.sum(np.square(embedding_stats.get("mean", [0]))) if embedding_stats else 0, 3)
        })

        # Grid 3: Métricas de Performance
        grid3 = create_grid("Performance do Sistema", {
            "Tempo Total (s)": round(elapsed_time, 2),
            "Tokens/Segundo": round(tokens/elapsed_time if elapsed_time > 0 else 0, 2),
            "CPU Total (%)": cpu_total,
            "Média CPU/Core (%)": round(np.mean(cpu_percent), 2),
            "RAM Utilizada (GB)": round(mem.used/1e9, 2),
            "RAM Total (GB)": round(mem.total/1e9, 2),
            "Uso RAM (%)": mem.percent,
            "Throughput (palavras/s)": round(words/elapsed_time if elapsed_time > 0 else 0, 2),
            "Eficiência CPU": round((tokens/elapsed_time)/(cpu_total + 1), 2),
            "Eficiência Memória": round((tokens * model_dim)/(mem.used + 1), 2)
        })

        # Grid 4: Métricas BERT
        grid4 = create_grid("Análise BERT", {
            "Modelo": model_name,
            "Temperatura": temperature,
            "Camadas Atenção": self.model.config.num_attention_heads,
            "Camadas Hidden": self.model.config.num_hidden_layers,
            "Tamanho Vocabulário": self.tokenizer.vocab_size,
            "Max Seq Length": self.model.config.max_position_embeddings,
            "Dropout Rate": self.model.config.hidden_dropout_prob,
            "Attention Dropout": self.model.config.attention_probs_dropout_prob,
            "Parâmetros (M)": round(sum(p.numel() for p in self.model.parameters())/1e6, 2),
            "Tipo Arquitetura": self.model.config.model_type
        })

        # Grid 5: Métricas Avançadas
        grid5 = create_grid("Métricas Avançadas", {
            "Densidade Semântica": round(embedding_density * (unique_words/words if words > 0 else 0), 3),
            "Complexidade Contextual": round(tokens/(unique_words + 1) * np.mean(embedding_stats.get("std", [0])) if embedding_stats else 0, 3),
            "Índice Coesão": round(min_norm/max_norm if max_norm > 0 else 0, 3),
            "Saturação Embedding": round(np.mean(np.abs(embedding_stats.get("mean", [0]))) if embedding_stats else 0, 3),
            "Eficiência Vetorial": round(unique_words/(model_dim * tokens) if tokens > 0 else 0, 3),
            "Score Qualidade": round((embedding_density * unique_words)/(tokens * np.std(embedding_stats.get("std", [1])) + 1) if embedding_stats else 0, 3),
            "Índice Dispersão": round(np.max(embedding_stats.get("std", [1]))/np.min(embedding_stats.get("std", [1])) if embedding_stats and np.min(embedding_stats.get("std", [1])) > 0 else 0, 3),
            "Cobertura Semântica": round(unique_words/self.tokenizer.vocab_size, 4),
            "Eficiência Tokenização": round(tokens/(words * model_dim) if words > 0 else 0, 3),
            "Score Global": round((embedding_density * unique_words)/(elapsed_time * np.mean(embedding_stats.get("std", [1])) + 1) if embedding_stats else 0, 3)
        })

        console.print(Panel(grid1, title="Métricas de Texto"))
        console.print(Panel(grid2, title="Análise de Embeddings"))
        console.print(Panel(grid3, title="Performance do Sistema"))
        console.print(Panel(grid4, title="Análise BERT"))
        console.print(Panel(grid5, title="Métricas Avançadas"))


if __name__ == "__main__":
    vectorizer = YAMLVectorizer()
    vectorizer.process_directory('generated-yaml-text-to-embedding')
