import zipfile
from datetime import datetime
import hashlib
from pathlib import Path
import shutil
import re
from rich.console import Console
from rich.panel import Panel

console = Console()

def gerar_hash():
    timestamp = datetime.now().timestamp()
    return hashlib.md5(str(timestamp).encode()).hexdigest()[:8]

def obter_ultima_versao(pasta_backup):
    padrao = re.compile(r'.*-(\d{4})\.zip$')
    ultima_versao = 0
    
    if pasta_backup.exists():
        for arquivo in pasta_backup.glob('*.zip'):
            match = padrao.match(arquivo.name)
            if match:
                versao = int(match.group(1))
                ultima_versao = max(ultima_versao, versao)
    
    return ultima_versao + 1

def criar_backup_projeto():
    # Configurações iniciais
    pasta_raiz = Path.cwd()
    nome_projeto = pasta_raiz.name
    pasta_backup = pasta_raiz / "backup"
    pasta_backup.mkdir(exist_ok=True)
    
    # Gerar nome do arquivo
    data_hora = datetime.now().strftime("%Y%m%d_%H%M%S")
    hash_unica = gerar_hash()
    versao = f"{obter_ultima_versao(pasta_backup):04d}"
    
    nome_zip = f"completo_backup_projeto-{nome_projeto}-{data_hora}-{hash_unica}-versao-{versao}.zip"
    caminho_zip = pasta_backup / nome_zip
    
    try:
        # Lista de diretórios e arquivos a serem ignorados
        ignorar = {
            'backup',
            '__pycache__',
            '.git',
            '.pytest_cache',
            '.venv',
            'venv',
            '.env',
            '.idea',
            '.vscode',
            'node_modules'
        }
        
        # Criar arquivo ZIP
        arquivos_incluidos = 0
        with zipfile.ZipFile(caminho_zip, 'w', zipfile.ZIP_DEFLATED) as zipf:
            for item in pasta_raiz.rglob('*'):
                # Ignorar diretórios da lista
                if any(ignore in item.parts for ignore in ignorar):
                    continue
                
                # Ignorar o próprio arquivo zip sendo criado
                if item == caminho_zip:
                    continue
                
                # Adicionar apenas arquivos (não diretórios)
                if item.is_file():
                    caminho_relativo = item.relative_to(pasta_raiz)
                    zipf.write(item, caminho_relativo)
                    arquivos_incluidos += 1
        
        console.print(Panel.fit(
            f"[green]✓ Backup criado com sucesso:[/green]\n"
            f"[blue]{nome_zip}[/blue]\n"
            f"[green]✓ {arquivos_incluidos} arquivos incluídos no backup[/green]\n"
            f"[green]✓ Local: {pasta_backup}[/green]",
            border_style="green"
        ))
        return True
        
    except Exception as e:
        console.print(f"[red]Erro ao criar backup: {str(e)}[/red]")
        return False

if __name__ == "__main__":
    try:
        console.print(Panel.fit(
            "[bold cyan]Criando backup completo do projeto[/bold cyan]",
            border_style="cyan"
        ))
        criar_backup_projeto()
    except KeyboardInterrupt:
        console.print("\n[yellow]Operação cancelada pelo usuário.[/yellow]")
    except Exception as e:
        console.print(f"[red]Erro inesperado: {str(e)}[/red]")
