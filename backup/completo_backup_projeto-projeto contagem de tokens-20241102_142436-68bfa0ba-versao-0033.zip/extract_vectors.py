import sqlite3
import numpy as np
from transformers import BertTokenizer, BertModel
import torch

def extract_vectors_and_words(db_path):
    """
    Extrai e processa vetores BLOB usando BERT.
    """
    try:
        # Inicializa BERT
        tokenizer = BertTokenizer.from_pretrained('bert-base-multilingual-cased')
        model = BertModel.from_pretrained('bert-base-multilingual-cased')
        
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()

        cursor.execute("SELECT word, vector FROM word_vectors")
        results = cursor.fetchall()

        processed_results = []
        for word, vector_blob in results:
            # Converte BLOB para numpy array
            vector = np.frombuffer(vector_blob, dtype=np.float32)
            
            # Processa a palavra com BERT
            inputs = tokenizer(word, return_tensors="pt", padding=True, truncation=True)
            with torch.no_grad():
                outputs = model(**inputs)
            
            # Pega o embedding da palavra (usando o [CLS] token)
            bert_embedding = outputs.last_hidden_state[:, 0, :].numpy()
            
            processed_results.append((word, vector, bert_embedding))

        conn.close()
        return processed_results

    except sqlite3.Error as e:
        print(f"Erro ao acessar o banco de dados: {e}")
        return None

if __name__ == "__main__":
    db_path = "vectors_continuo.db"
    results = extract_vectors_and_words(db_path)

    if results:
        for word, original_vector, bert_vector in results:
            print(f"Palavra: {word}")
            print(f"Vetor Original: {original_vector.shape}")
            print(f"Vetor BERT: {bert_vector.shape}")
            print("-" * 50)
    else:
        print("Nenhum dado extraído.")
